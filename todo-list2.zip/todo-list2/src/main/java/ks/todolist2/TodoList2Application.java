package ks.todolist2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodoList2Application {

	public static void main(String[] args) {
		SpringApplication.run(TodoList2Application.class, args);
	}

}
