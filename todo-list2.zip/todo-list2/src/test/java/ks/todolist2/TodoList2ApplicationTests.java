package ks.todolist2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodoList2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
